// true if  we should enter cardreader mode
bool shouldEnterReader();

// run cardreader mode. does not return currently
void runCardReader();
